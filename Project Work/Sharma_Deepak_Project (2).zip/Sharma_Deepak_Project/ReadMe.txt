
How to run the application ?

By execting below script
Project_Main_function('71.jpg');

How to perceive Output
THe last output image will show two outputs left and Right
Left is the output of my purposed algorithm
Right is the output of the post-processing step suggested by Yi Zhang.
 